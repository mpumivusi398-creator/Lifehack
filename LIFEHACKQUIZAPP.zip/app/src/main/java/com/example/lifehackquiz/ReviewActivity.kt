package com.example.lifehackquiz

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ReviewActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_review)

        val reviewText: TextView = findViewById(R.id.tvReview)
        val backButton: Button = findViewById(R.id.btnBack)

        val answers = intent.getSerializableExtra("ANSWERS") as? ArrayList<Triple<String, Boolean, Boolean>>

        val reviewBuilder = StringBuilder()
        answers?.forEachIndexed { index, triple ->
            val (question, userAnswer, correctAnswer) = triple
            reviewBuilder.append("${index + 1}. $question\n")
            reviewBuilder.append("Your Answer: ${if (userAnswer) "True" else "False"}\n")
            reviewBuilder.append("Correct Answer: ${if (correctAnswer) "True" else "False"}\n\n")
        }

        reviewText.text = reviewBuilder.toString()

        backButton.setOnClickListener { finish() }
    }
}