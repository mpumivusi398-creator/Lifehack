package com.example.lifehackquiz

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ScoreActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_score)

        val tvScore: TextView = findViewById(R.id.tvScore)
        val btnReview: Button = findViewById(R.id.btnReview)

        val score = intent.getIntExtra("SCORE", 0)
        val total = intent.getIntExtra("TOTAL", 0)
        val answers = intent.getSerializableExtra("ANSWERS") as? ArrayList<Triple<String, Boolean, Boolean>>

        tvScore.text = "Your Score: $score / $total"

        btnReview.setOnClickListener {
            val intent = Intent(this, ReviewActivity::class.java)
            intent.putExtra("ANSWERS", answers)
            startActivity(intent)
        }
    }
}       