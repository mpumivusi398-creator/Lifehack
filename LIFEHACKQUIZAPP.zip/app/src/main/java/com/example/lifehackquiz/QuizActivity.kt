package com.example.lifehackquiz

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class QuizActivity : AppCompatActivity() {

    private lateinit var tvQuestion: TextView
    private lateinit var btnOption1: Button
    private lateinit var btnOption2: Button

    private var currentQuestionIndex = 0
    private var score = 0

    // Track user answers (question, user answer, correct answer)
    private val userAnswers = mutableListOf<Triple<String, Boolean, Boolean>>()

    private val questions = listOf(
        Pair("The Eiffel Tower is in Paris.", true),
        Pair("The human body has 206 bones.", true),
        Pair("Sharks are mammals.", false),
        Pair("The capital of Japan is Tokyo.", true),
        Pair("Water boils at 50°C.", false),
        Pair("The Earth revolves around the Sun.", true),
        Pair("Bananas grow on trees.", false),
        Pair("The Great Wall of China is visible from space.", false),
        Pair("The currency of South Africa is the Rand.", true),
        Pair("Mount Everest is the tallest mountain on Earth.", true),
        Pair("Penguins can fly.", false),
        Pair("The Amazon River is the longest river in the world.", false),
        Pair("Light travels faster than sound.", true),
        Pair("The human heart has four chambers.", true),
        Pair("Gold is heavier than water.", true)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz)

        tvQuestion = findViewById(R.id.tvQuestion)
        btnOption1 = findViewById(R.id.btnOption1)
        btnOption2 = findViewById(R.id.btnOption2)

        loadQuestion()

        btnOption1.setOnClickListener { checkAnswer(true) }
        btnOption2.setOnClickListener { checkAnswer(false) }
    }

    private fun loadQuestion() {
        if (currentQuestionIndex < questions.size) {
            val (questionText, _) = questions[currentQuestionIndex]
            tvQuestion.text = questionText
        } else {
            val intent = Intent(this, ScoreActivity::class.java)
            intent.putExtra("SCORE", score)
            intent.putExtra("TOTAL", questions.size)
            intent.putExtra("ANSWERS", ArrayList(userAnswers))
            startActivity(intent)
            finish()
        }
    }

    private fun checkAnswer(answer: Boolean) {
        val (questionText, correctAnswer) = questions[currentQuestionIndex]

        // ✅ Correct add() call
        userAnswers.add(Triple(questionText, answer, correctAnswer))

        if (answer == correctAnswer) score++
        currentQuestionIndex++
        loadQuestion()
    }
}